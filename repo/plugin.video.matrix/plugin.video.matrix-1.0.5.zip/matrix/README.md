MATRIX is a vod arabic addon
================================

Introduction :
it is an all in one addon that lets you watch different content available online 
matrix is an arabic moded version of the french addon Vstream  credits for the core code goes to LordVenom & TmpName .
--------------------------------------------------------------------------

Installation
------------

First step is the grab my repo

you can have it by 2 methods : 
## first
settings-> file manager->add source : http://repo.web44.net/zombi name it zombi
 than go to 
 addons->addons browser->install from zip->zombi--repository.zombi-0.0.1.zip
## second
Simply download the [repo ZIP file][download]  to your XBMC/Kodi device and install through the menu via:
System -> Settings -> Add-ons -> Install from zip file.

Once the repository ZIP file is installed, you can install the add-on : 
 Add-ons > Install from repository > Zombi Repository > Video addons 
 

Issues
------
For any issues requests or bug reports, please file them on the [issues page][issues].

Enjoy

[repository]: https://github.com/zombiB/zombi-addons/tree/master/repo/repository.zombi
[download]: https://github.com/zombiB/zombi-addons/blob/master/repo/repository.zombi/repository.zombi-0.0.1.zip?raw=true
[issues]: https://github.com/zombiB/matrix/issues
