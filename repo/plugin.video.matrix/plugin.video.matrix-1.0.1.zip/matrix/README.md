# matrix
vod arabic content addon

Introduction : matrix is an arabic version of lordvenom's addon Vstream
matrix addon works like a browser il lets you watch contents avaiable on public websites

