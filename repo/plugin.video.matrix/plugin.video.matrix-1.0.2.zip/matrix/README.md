# matrix
vod arabic content addon

Introduction : matrix is an arabic version of lordvenom's addon Vstream
--------------------------------------------------------------------------
matrix addon works like a browser il lets you watch contents avaiable on public websites
--------------------------
how to install 
first get my repo :
 settings -- file manager -- add source : http://repo.web44.net/zombi name it zombi than go to 
 addons -- addons browser -- install from zip --zombi--repository.zombi-0.0.1.zip
 than get the addon ;
 Add-ons > Install from repository > Zombi Repository > Video addons 
 

