#-*- coding: utf-8 -*-

from resources.hosters.hoster import iHoster
from resources.lib.comaddon import VSlog, dialog

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'directplay', 'Direct-Link')

    def setUrl(self, url):
        self._url = str(url).replace('+', '%2B').replace('||', '%20')

    def _getMediaLinkForGuest(self, autoPlay = False):

        if 'googleusercontent.com' in self._url or 'video-downloads' in self._url:
            dialog().VSinfo(f'قد لا يقبل التشغيل المباشر ، جرب تحميل وتشغيل')

        if self._url:
            return True, self._url

        return False, False
